//=========================================
//  TIP FEED UI SETUP
//=========================================

var socket = io.connect('http://localhost:80');
socket.on('new tip', function(tip){
  $('#feed').prepend('<li class="tip">'+tip+'</li>');
});

//=========================================
//  JQUERY
//=========================================
$(document).ready(function(){

});
