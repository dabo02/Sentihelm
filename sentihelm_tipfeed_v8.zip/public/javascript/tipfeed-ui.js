//=========================================
//  TIP FEED UI SETUP
//=========================================

//Connect to server side socket
// var socket = io.connect('http://localhost:80');
var socket = io.connect('http://sentihelm.elasticbeanstalk.com');

//Catch event when new tip arrives server-side.
//Extract all tip info from received JSON
socket.on('new tip', function(newTip){
  var tip = newTip.tip;
  var name = tip.firstName +" "+tip.lastName;
  var crimeType = tip.crimeType;
  var crimeImage;
  switch(crimeType){
  case 'Assault':
    crimeImage = "http://199.85.204.123/fb_images/0.png";
    break;
  case 'Child Abuse':
    crimeImage = "http://199.85.204.123/fb_images/1.png";
    break;
  case 'Domestic Violence':
    crimeImage = "http://199.85.204.123/fb_images/2.png";
    break;
  case 'Drugs':
    crimeImage = "http://199.85.204.123/fb_images/3.png";
    break;
  case 'Murder':
    crimeImage = "http://199.85.204.123/fb_images/4.png";
    break;
  case 'Animal Abuse':
    crimeImage = "http://199.85.204.123/fb_images/5.png";
    break;
  case 'Robbery':
    crimeImage = "http://199.85.204.123/fb_images/6.png";
    break;
  case 'Rape':
    crimeImage = "http://199.85.204.123/fb_images/7.png";
    break;
  default:
    crimeImage = "http://199.85.204.123/fb_images/8.png"
  }
  var phone = tip.phone;
  var channel = tip.channel;
  var videoUrl = tip.videoUrl;
  var imageUrl = tip.imageUrl;
  var audioUrl = tip.audioUrl;
  var crimeDescription = tip.crimeDescription;
  if(crimeDescription==undefined){
    crimeDescription="";
  }
  var mapId = tip.objectId;
  var latitude = tip.latitude;
  var longitude = tip.longitude;
  //Replace HTML placeholders with extracted values
  var tipHTML = '<li class="tip"><div class="tip-header"><span>'+name+'</span></div>'+
  '<div class="tip-body"><div class="left"><img src="'+crimeImage+'"/>'+
  '<br><span>'+crimeType+'</span><div class="contact-info">CONTACT USER\n<span '+
  'class="contact-number">'+phone+'</span><button id="'+channel+'" class="notification-button">'+
  'Send Notification</button></div></div><div class="center">'+
  '<div class="attachments"><a id="videoAtt" href="'+videoUrl+'"><img src="./'+
  'resources/images/videoAtt.png"/></a><a id="imageAtt" href="'+imageUrl+'"><img' +
  ' src="./resources/images/imageAtt.png"/></a><a id="audioAtt" href="'+audioUrl+'"><img'+
  ' src="./resources/images/audioAtt.png"/></a></div><div class="crime'+
  '-description"><span>'+crimeDescription+'</span></div></div><div id="'+mapId+
  '"class="right"></div></div></li>';
  //Add tip to top of tip feed
  $('#feed').prepend(tipHTML);
  $('.tip').first().hide().slideDown(750, function(){
    //Alternate method that assings unique id to each
    //map view; might be useful when dealing with tip queue
    // renderMap(mapId, latitude, longitude);
    renderMap(latitude, longitude);
  });
  validateAttachments();
});

//=========================================
//  HELPER FUCTIONS
//=========================================

//Reders google map with provided coordinates
//in the rightmost division of a tip
function renderMap(latitude, longitude){
  var location = new google.maps.LatLng(latitude, longitude);
  //Might use this when building tip queue:
  //var mapCanvas = document.getElementById(mapId);
  var mapCanvas = $('.tip').first().find('.tip-body').find('.right')[0];
  var mapOptions = {
    center: location,
    zoom: 14,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  var map = new google.maps.Map(mapCanvas, mapOptions);
  var marker = new google.maps.Marker({
    position: location,
    map: map,
    title: 'User Location'
  });
}

//Checks attachments to see if they are available;
//if not, disable their links
function validateAttachments(){
  var attachments = $('.tip').first().find('.center').find('.attachments');
  var videoAtt = attachments.find('#videoAtt');
  var imageAtt = attachments.find('#imageAtt');
  var audioAtt = attachments.find('#audioAtt');
  if(videoAtt.attr('href')=='#'){
    videoAtt.addClass('disabled-link');
  }
  if(imageAtt.attr('href')=='#'){
    imageAtt.addClass('disabled-link');
  }
  if(audioAtt.attr('href')=='#'){
    audioAtt.addClass('disabled-link');
  }
}

//=========================================
//  JQUERY
//=========================================
$(document).ready(function(){
  //Send a push notification to the user
  $('.notification-button').on('click', function(){
    var notifModal = $('.notification-modal');
    $('body').css('opacity',0.6);
    notifModal.show();
    var userChannel = $(this).attr('id');
    // Parse.Push.send(
    //   {
    //     channels: [ userChannel ],
    //     data: {
    //       alert: "text box value"
    //     }
    //   },
    //   {
    //     success: function() {
    //       console.log("SUCCESS");
    //     },
    //     error: function(error) {
    //       console.log("FAILED: "+error);
    //     }
    //   });
    // });
  });
