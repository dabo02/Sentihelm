(function(){
  var app = angular.module('sentihelm',[]);

  app.directive('header', function(){
    return{
      restrict:'E',
      templateUrl:'header.html',
      controller: function(){
        this.drawerOn=false;
        this.drawerIcon = '../resources/images/drawer-icon.png';
        this.logo = '../resources/images/sentihelm.png';

        this.toggleIcon = function(toggle){
          if(toggle){
            this.drawerIcon = '../resources/images/drawer-icon-alt.png';
          }
          else{
            this.drawerIcon = '../resources/images/drawer-icon.png';
          }
        };

        this.toggleDrawer = function(){
          if(!this.drawerOn){
            $('.drawer').animate({left:"0"},600);
          }
          else{
            $('.drawer').animate({left:"-15%"},600);
          }
          this.drawerOn=!this.drawerOn;
        }
      },
      controllerAs:'header'
    };
  });

  app.directive('drawer', function(){
    return{
      restrict:'E',
      templateUrl:'drawer.html',
      controller: function(){
        this.entries=[
          {name:'Tip Feed', icon:'../resources/images/drawer-tip.png'},
          {name:'Video Feeds', icon:'../resources/images/drawer-live911.png'},
          {name:'Alert Users', icon:'../resources/images/drawer-info.png'},
          {name:'Option A', icon:'../resources/images/drawer-testing.png'},
          {name:'Option B', icon:'../resources/images/drawer-testing.png'},
          {name:'Option C', icon:'../resources/images/drawer-testing.png'}
        ];
      },
      controllerAs: 'drawer'
    };
  });

  app.directive('tipFeed', function(){
    return{
      restrict:'E',
      templateUrl:'tip-feed.html'
    };
  });

})();
